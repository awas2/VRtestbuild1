# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2019-11-04

Deprecate package

## [1.18.3] - 2019-03-29

Update .meta files so that plugins are overridable.
Rename Documentation folder

## [1.18.2] - 2019-01-07

Update Documentation, npm ignores Documentation~

## [1.18.1] - 2019-01-07

Update licenses
Update package display name
Update Documentation~

## [1.18.0] - 2018-10-31

updating to match the released GVR version

## [1.0.0] - 2018-10-01

First official version of the package
