**Third Party Notices**

Component Name: _GVR SDK 1.180_

All rights reserved. Use of the Google VR SDK for Unity requires agreeing to and complying with the Google APIs Terms of Service accessed via: https://developers.google.com/terms/ (Please be aware that you may need to register with Google to access certain APIs). If you cannot comply with Google APIs Terms of Service, do not use this SDK.